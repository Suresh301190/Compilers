class Program{


	int x, y, z, a[8];
	int b[10];
	bool c[5];

	int i = 7;

	int main(){
		int i, j, k;
		x = 5;
		y = a[8];
		a[5] = x;
		a[3] = a[7];

		if(x < y || y == 0){
			z = 2;
		}
		else {
			z = i * j + k;
		}
	}

	bool foo(int p, bool q){
		y = 7;

		for i = 8, i < 25{
			z = 2;
		}
	}
}
