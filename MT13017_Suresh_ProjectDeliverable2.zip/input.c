class Program{

	int x, z[10];
	bool b = false;

	int main( int i, bool b){
		int x, y, z;
		x = 5;

		if(x == y){
			z = false;
		}

		for( x = 5; z == y) {

		}

		return (0);
	}
}
